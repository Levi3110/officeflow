from __future__ import annotations

import asyncio
import math
import random
import time

from .models import Primitive


class HumanBehaviourEngine:
    """A session-scoped persona; conditional timing, not an independent delay per action."""

    def __init__(self, persona, event, realtime=True):
        self.persona, self.event, self.realtime = persona, event, realtime
        self.random = random.Random(persona.seed)
        self.rhythm = 1.0
        self.fatigue = 0.0
        self.elapsed = 0.0

    async def pause(self, category, seconds):
        sampled = max(0, seconds * self.persona.pause_scale)
        started = time.monotonic()
        if self.realtime:
            await asyncio.sleep(sampled)
        else:
            await asyncio.sleep(0)
        elapsed = time.monotonic() - started
        self.elapsed += elapsed
        self.event(
            "timing",
            {
                "category": category,
                "requested_seconds": sampled,
                "elapsed_seconds": elapsed,
                "simulated_timing": not self.realtime,
            },
        )

    async def context_pause(self, context, characters=0):
        if context == "read":
            seconds = min(6, max(0.4, characters / self.random.uniform(45, 80)))
        elif context == "switch":
            seconds = self.random.lognormvariate(math.log(0.45), 0.25)
        else:
            seconds = self.random.lognormvariate(math.log(0.18), 0.35)
        await self.pause("behaviour." + context, seconds)

    async def type(self, text, emit, allow_typo=False):
        for index, char in enumerate(text):
            self.rhythm = 0.88 * self.rhythm + 0.12 * self.random.uniform(0.75, 1.3)
            self.fatigue = min(0.18, self.fatigue + 0.00002)
            # Never perturb commands, URLs, numbers or formulas. Fix prose typos before continuing.
            if (
                allow_typo
                and char.isascii()
                and char.isalpha()
                and self.random.random() < self.persona.typo_probability
            ):
                wrong = self.random.choice("abcdefghijklmnopqrstuvwxyz".replace(char.lower(), ""))
                await emit(Primitive(kind="text", value=wrong))
                await self.pause("behaviour.typo_notice", self.random.uniform(0.12, 0.4))
                await emit(Primitive(kind="key", value="backspace"))
            await emit(Primitive(kind="text", value=char))
            interval = self.random.lognormvariate(
                math.log((1 + self.fatigue) * self.rhythm / self.persona.characters_per_second), 0.24
            )
            if char in ".!?\n":
                interval += self.random.uniform(0.15, 0.5)
            elif char == " " and index % 4 == 0:
                interval += self.random.uniform(0.05, 0.22)
            await self.pause("behaviour.typing", interval)

    async def move_to(self, origin, target, emit):
        dx, dy = target[0] - origin[0], target[1] - origin[1]
        distance = math.hypot(dx, dy)
        if distance < 1:
            return
        bend = self.random.uniform(-0.14, 0.14)
        control = (origin[0] + dx * 0.45 - dy * bend, origin[1] + dy * 0.45 + dx * bend)
        duration = min(0.9, 0.12 + 0.11 * math.log2(distance / 24 + 1)) * self.random.uniform(0.9, 1.1)
        steps = max(6, int(duration / 0.025))
        for step in range(1, steps + 1):
            t = step / steps
            # Smooth acceleration/deceleration with a small, session-consistent curved path.
            t = 3 * t * t - 2 * t * t * t
            point = [
                (1 - t) ** 2 * origin[i] + 2 * (1 - t) * t * control[i] + t * t * target[i] for i in (0, 1)
            ]
            await emit(Primitive(kind="move", value=point))
            await self.pause("behaviour.pointer", duration / steps)
