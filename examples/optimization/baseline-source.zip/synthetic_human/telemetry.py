from __future__ import annotations

import json
import math
import os
import platform
import statistics
import threading
import time
from collections import Counter

import psutil


class TelemetryCollector:
    """Independent OS sampler. It never consumes executor commands to invent activity."""

    def __init__(self, path, mode, interval=0.5):
        self.path, self.mode, self.interval = path, mode, interval
        self.stopped = threading.Event()
        self.thread = None
        self.processes = {}

    def start(self):
        self.thread = threading.Thread(target=self._run, name="os-telemetry", daemon=True)
        self.thread.start()

    def _sample(self):
        rows = []
        for info in psutil.process_iter(["pid", "name", "create_time"]):
            try:
                name = info.info["name"] or ""
                if info.pid != os.getpid() and not any(
                    x in name.lower() for x in ("chrome", "soffice", "libreoffice")
                ):
                    continue
                identity = (info.pid, info.info["create_time"])
                proc = self.processes.setdefault(identity, psutil.Process(info.pid))
                io = None
                if hasattr(proc, "io_counters"):
                    try:
                        io = proc.io_counters()._asdict()
                    except (psutil.AccessDenied, NotImplementedError):
                        pass
                rows.append(
                    {
                        "pid": proc.pid,
                        "name": name,
                        "runner": proc.pid == os.getpid(),
                        "cpu_percent": proc.cpu_percent(),
                        "rss_bytes": proc.memory_info().rss,
                        "threads": proc.num_threads(),
                        "io": io,
                    }
                )
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        sample = {
            "kind": "os.sample",
            "timestamp": time.time(),
            "monotonic": time.monotonic(),
            "backend": self.mode,
            "source": "psutil",
            "processes": rows,
            "scope": "runner and all matching app processes; includes unrelated app sessions",
            "cpu_first_sample_may_be_zero": True,
        }
        if self.mode == "macos" and platform.system() == "Darwin":
            try:
                import Quartz as Q

                sample["input_counters"] = {
                    name: int(
                        Q.CGEventSourceCounterForEventType(Q.kCGEventSourceStateCombinedSessionState, kind)
                    )
                    for name, kind in (
                        ("key_down", Q.kCGEventKeyDown),
                        ("mouse_down", Q.kCGEventLeftMouseDown),
                        ("scroll", Q.kCGEventScrollWheel),
                    )
                }
                sample["input_scope"] = "entire login session, cumulative; not attributable solely to agent"
            except Exception as exc:
                sample["input_unavailable"] = str(exc)
        return sample

    def _run(self):
        with self.path.open("a") as stream:
            while not self.stopped.is_set():
                try:
                    sample = self._sample()
                except Exception as exc:
                    sample = {"kind": "collector.error", "timestamp": time.time(), "error": str(exc)}
                stream.write(json.dumps(sample) + "\n")
                stream.flush()
                self.stopped.wait(self.interval)

    def stop(self):
        self.stopped.set()
        if self.thread:
            self.thread.join(timeout=5)


def export_audit(store, path):
    with path.open("w") as stream:
        for row in store.db.execute("SELECT * FROM events ORDER BY seq"):
            stream.write(
                json.dumps(
                    {
                        "seq": row["seq"],
                        "timestamp": row["time"],
                        "kind": row["kind"],
                        "body": json.loads(row["body"]),
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )


def metrics(store, telemetry_path):
    events = [(r["kind"], json.loads(r["body"])) for r in store.db.execute("SELECT kind,body FROM events")]
    timing = {}
    for kind, body in events:
        if kind == "timing":
            category = body["category"]
            timing[category] = timing.get(category, 0) + body["elapsed_seconds"]
    samples = (
        [json.loads(line) for line in telemetry_path.read_text().splitlines()]
        if telemetry_path.exists()
        else []
    )
    samples = [s for s in samples if s["kind"] == "os.sample"]
    model_calls = [body for kind, body in events if kind == "model.call"]
    rows = {
        r["status"]: r["n"] for r in store.db.execute("SELECT status,COUNT(*) n FROM actions GROUP BY status")
    }
    intervals = [
        body["requested_seconds"]
        for kind, body in events
        if kind == "timing" and body["category"] == "behaviour.typing"
    ]
    bins = Counter(int(value / 0.025) for value in intervals)
    entropy = (
        -sum((n / len(intervals)) * math.log2(n / len(intervals)) for n in bins.values()) if intervals else 0
    )
    action_types = dict(Counter(body["kind"] for kind, body in events if kind == "action.verified"))
    return {
        "actions_by_status": rows,
        "handoffs": sum(k == "handoff.committed" for k, _ in events),
        "verified_action_types": action_types,
        "typing_requested_interval_cv": statistics.pstdev(intervals) / statistics.mean(intervals)
        if intervals and statistics.mean(intervals)
        else 0,
        "typing_requested_entropy_bits_25ms_bins": entropy,
        "typing_timing_note": "Requested persona intervals; audit dispatch times and OS counters are separate evidence.",
        "timing_seconds": timing,
        "model_calls": len(model_calls),
        "model_input_tokens": sum(b.get("input_tokens", 0) for b in model_calls),
        "model_output_tokens": sum(b.get("output_tokens", 0) for b in model_calls),
        "os_samples": len(samples),
        "peak_combined_app_rss_bytes": max(
            [sum(p["rss_bytes"] for p in s["processes"]) for s in samples] or [0]
        ),
        "peak_combined_cpu_percent": max(
            [sum(p["cpu_percent"] for p in s["processes"]) for s in samples] or [0]
        ),
        "runner_peak_rss_bytes": max(
            [p["rss_bytes"] for s in samples for p in s["processes"] if p.get("runner")] or [0]
        ),
        "runner_peak_cpu_percent": max(
            [p["cpu_percent"] for s in samples for p in s["processes"] if p.get("runner")] or [0]
        ),
        "evaluation_note": "Measured diagnostics, not a benchmark authenticity score.",
    }
