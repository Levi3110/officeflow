from __future__ import annotations

import re

from .models import Primitive as P


class ApplicationAdapters:
    def __init__(self, settings):
        self.settings = settings
        self.mod = "command"

    def plan(self, action):
        kind, data = action.kind, action.payload
        if kind == "navigate":
            return [
                P(kind="launch", value=[self.settings.browser_app]),
                P(kind="pause", value="switch"),
                P(kind="hotkey", value=[self.mod, "l"]),
                P(kind="text", value=action.target),
                P(kind="key", value="enter"),
            ]
        if kind == "follow_link":
            # Find the visible link, then activate it using browser keyboard focus.
            return [
                P(kind="hotkey", value=[self.mod, "f"]),
                P(kind="text", value=data["link_text"]),
                P(kind="key", value="escape"),
            ]
        if kind == "read_page":
            return [P(kind="hotkey", value=[self.mod, "a"]), P(kind="hotkey", value=[self.mod, "c"])]
        if kind == "scroll":
            return [P(kind="scroll", value=data.get("amount", -4)), P(kind="pause", value="read")]
        if kind == "open_file":
            return [P(kind="launch", value=[self.settings.office_app, action.target])]
        if kind == "set_cell":
            match = re.fullmatch(r"([A-H])([1-9]\d?)", data["cell"])
            if not match:
                raise ValueError("MVP supports A1:H99")
            col, row = ord(match[1]) - 65, int(match[2]) - 1
            # Go from A1 each time: replay overwrites the cell instead of appending.
            steps = [P(kind="key", value="escape"), P(kind="hotkey", value=[self.mod, "home"])]
            steps += [P(kind="key", value="right")] * col + [P(kind="key", value="down")] * row
            steps += [
                P(kind="text", value=str(data["value"])),
                P(kind="key", value="enter"),
                P(kind="hotkey", value=[self.mod, "s"]),
            ]
            return steps
        if kind == "write_document":
            return [
                P(kind="hotkey", value=[self.mod, "a"]),
                P(kind="text", value=data["text"], allow_typo=True),
                P(kind="hotkey", value=[self.mod, "s"]),
            ]
        raise ValueError(f"unsupported action: {kind}")

    def expected_app(self, action):
        if action.kind in ("navigate", "follow_link", "read_page", "scroll"):
            return self.settings.browser_app
        return self.settings.office_app
